class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  c_fc : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  gelu : __torch__.torch.nn.modules.activation.GELU
  c_proj : __torch__.torch.nn.modules.linear.___torch_mangle_2.Linear
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.torch.nn.modules.container.Sequential,
    input: Tensor) -> Tensor:
    c_fc = self.c_fc
    gelu = self.gelu
    c_proj = self.c_proj
    dropout = self.dropout
    input0 = (c_fc).forward(input, )
    input1 = (gelu).forward(input0, )
    input2 = (c_proj).forward(input1, )
    return (dropout).forward(input2, )
  def __len__(self: __torch__.torch.nn.modules.container.Sequential) -> int:
    return 4
